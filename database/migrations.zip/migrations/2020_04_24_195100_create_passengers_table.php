<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePassengersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('passengers', function (Blueprint $table) {
            $table->id();
            $table->string('p_first_name', 50)->nullable();
            $table->string('p_last_name', 50)->nullable();
            $table->string('p_phone', 20)->nullable();
            $table->string('p_email', 100)->nullable();
            $table->string('post_code', 10);
            $table->string('address');
            $table->decimal('p_point', 10)->nullable()->default(0.00);
            $table->string('phone_verification', 25)->nullable();
            $table->integer('phone_verification_status')->nullable()->default(0);
            $table->string('country', 100)->default('Australia');
            $table->string('avatar', 55)->nullable();
            $table->string('gender', 20)->nullable();
            $table->ipAddress('last_ip_address', 45)->nullable();
            $table->ipAddress('ip_address', 45)->nullable();
            $table->string('username', 100);
            $table->string('password', 40);
            $table->string('activation_code', 40)->nullable();
            $table->string('forgotten_password_code', 40)->nullable();
            $table->integer('forgotten_password_time')->unsigned()->nullable();
            $table->string('remember_code', 40)->nullable();
            $table->integer('created_on')->unsigned();
            $table->integer('last_login')->unsigned()->nullable();
            $table->boolean('active')->nullable();
            $table->boolean('trash_status')->default(0);
            $table->integer('created_by');
          
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('passengers');
    }
}

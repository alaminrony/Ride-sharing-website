<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDriversTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {



        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->string('d_first_name')->nullable();
            $table->string('d_last_name')->nullable();
            $table->string('d_email');
            $table->string('d_phone');
            $table->date('date_of_birth')->nullable();
            $table->string('driving_licence_no');
            $table->string('driving_licence_photo')->nullable();
            $table->string('australian_driver_no');
            $table->string('cab_driver_no');
            $table->integer('driver_type_id');
            $table->integer('discout_id')->nullable();
            $table->string('discout_amount')->nullable();
            $table->decimal('d_point',10, 2);
            $table->decimal('rating_value',10, 2);
            $table->integer('cab_id');
            $table->string('phone_varification')->nullable();
            $table->string('phone_varification_status')->nullable();
            $table->ipAddress('last_ip_address')->nullable();
            $table->ipAddress('ip_address')->nullable();
            $table->string('user_name');
            $table->string('password');
            $table->string('activation_code')->nullable();
            $table->string('forgotten_password_code')->nullable();
            $table->integer('forgotten_password_time')->nullable();
            $table->string('remember_code')->nullable();
            $table->integer('created_on')->nullable();
            $table->integer('last_login')->nullable();
            $table->tinyInteger('active')->nullable();
            $table->integer('is_online');
            $table->integer('trash_status');
            $table->string('current_location_gps')->nullable();
            $table->string('latitude')->nullable();
            $table->string('longitude')->nullable();
            $table->string('country');
            $table->text('address');
            $table->string('city');
            $table->string('state');
            $table->string('post_code');
            $table->string('avatar')->nullable();
            $table->string('gender')->nullable();
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->integer('login_pic')->nullable();
            $table->string('profile_photo')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('drivers');
    }
}

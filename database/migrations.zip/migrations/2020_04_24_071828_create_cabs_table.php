<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCabsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cabs', function (Blueprint $table) {
            $table->id();
            $table->integer('cab_type_id')->nullable();
            $table->integer('driver_id')->nullable();
            $table->string('license_plate')->nullable();
            $table->string('model_number')->nullable();
            $table->string('color');
            $table->text('description')->nullable();
            $table->string('manufacturer');
            $table->string('manufacturer_year');
            $table->string('taxi_operator');
            $table->string('adult');
            $table->string('children');
            $table->string('wheelchair');
            $table->string('adult_type')->nullable();
            $table->string('children_type')->nullable();
            $table->string('wheelchair_type')->nullable();
            $table->string('photo')->nullable();
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cabs');
    }
}
